export declare function validateName(name: string): void;
export declare const htmlSelectorRe: RegExp;
export declare function validateHtmlSelector(selector: string): void;
export declare function validateProjectName(projectName: string): void;
