import { Rule } from '@angular-devkit/schematics';
import { UpdateSchema } from './schema';
export default function (options: UpdateSchema): Rule;
