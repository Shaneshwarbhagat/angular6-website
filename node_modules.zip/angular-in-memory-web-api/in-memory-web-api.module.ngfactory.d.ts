import * as i0 from '@angular/core';
import * as i1 from './in-memory-web-api.module';
export declare const InMemoryWebApiModuleNgFactory: i0.NgModuleFactory<i1.InMemoryWebApiModule>;
