import * as ts from 'typescript';
export declare function resolveEntryModuleFromMain(mainPath: string, host: ts.CompilerHost, program: ts.Program): string | null;
